/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <utility>

using namespace std;

void print_vector(vector<int>&arr){
    for(auto element: arr){
        cout << element << " "; 
    }
    cout << endl; 
}


//////////////////////////////////////////////////////////////////
// FIND THE LEFTMOST AND RIGHTMOST OCCURENCE INDEX OF AN ELEMENT
//////////////////////////////////////////////////////////////////
int find_leftmost_occurence(vector<int>&arr, int n, int k){
    
    int start = 0, end = (arr.size() -1); 
    int mid = start + ((end-start)/2); 
    
    int res = -1;          // If answer not found then -1
    
    while(start<=end){
        
        if(arr[mid] == k){
            res = mid;
            end = mid -1;     // If solution found in the middle then find the leftmost occurence. 
        }
        else if(k > arr[mid]){
            start = mid +1;   // If key is greater than mid, then no occurence exists at left side. 
        }
        else if (k < arr[mid]){
            end = mid -1;
        }
        
        mid = start + ((end-start)/2);
    }
    return res; 
}

int find_rightmost_occurence(vector<int>&arr, int n, int k){
    
    int start = 0, end = (arr.size() -1); 
    int mid = start + ((end-start)/2); 
    
    int res = -1;          // If answer not found then -1
    
    while(start<=end){
        
        if(arr[mid] == k){
            res = mid;
            start = mid +1;     // If solution found in the middle then find the rightmost occurence. 
        }
        else if(k > arr[mid]){
            start = mid +1;   // If key is greater than mid, then no occurence exists at left side. 
        }
        else if (k < arr[mid]){
            end = mid -1;
        }
        
        mid = start + ((end-start)/2);
    }
    return res; 
}

pair<int,int> find_first_and_last_occurence(vector<int>& arr, int n, int k){
    
    int a = find_leftmost_occurence(arr, arr.size(), k);
    int b = find_rightmost_occurence(arr, arr.size(), k); 
    
    return make_pair(a,b); 
}

///////////////////////////////////////////////
// COUNT ALL OCCURENCES USING BINARY SEARCH
///////////////////////////////////////////////
int count_all_occurences(vector<int>& arr, int k){
    
    int a = find_leftmost_occurence(arr, arr.size(), k);
    int b = find_rightmost_occurence(arr, arr.size(), k); 
    
    int res = (b-a)+1; 
    
    return res; 
    
}


int main()
{
    vector<int> arr1 = {3,3,3,3,3};
    
    int res_left = find_leftmost_occurence(arr1, arr1.size(), 3); 
    int res_right = find_rightmost_occurence(arr1, arr1.size(), 3);
    
    cout << "The left most occurence of key is " << res_left << endl << "The right most occurence of key is " << res_right << endl; 
    
    pair<int,int> res1 = find_first_and_last_occurence(arr1, arr1.size(), 3);
    
    cout << "The first and last occurences of key are : " << res1.first << ", " << res1.second << endl; 

    int res2 = count_all_occurences(arr1, 3); 
    
    cout << "There are a total of " << res2 << " occurences of key in the array" << endl; 

    return 0;
}