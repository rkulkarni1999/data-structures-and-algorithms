/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

// Find the Sum of all elements in an Array. 

#include <iostream>

using namespace std;

int sum_of_array_elements(int A[]){
    int ii, sum, size = 0; 
    size = sizeof(A) / sizeof(A[0]);
    cout << "Size of A : " << sizeof(A) << endl;        // Size of pointer variable is 8 
    cout << "Size of A[0] : " << sizeof(A[0]) << endl;  // Size of int is 4
    for(ii=0; ii<size; ii++){
        sum = sum + A[ii]; 
    }
    return sum; 
}

void Double(int* A, int size){
    for(int ii=0; ii<size; ii++){
        A[ii] = 2*A[ii]; 
    }
}

int main()
{
    
    int A[] = {1,2,3,4,5};
    // int total = sum_of_array_elements(A); 
    // cout << "The sum of all elements in the array is : "<< total << endl; 
    // Hence, to avoid this problem, the size variable should be in the main function and 
    // not in the user defined function. 
    
    int size = sizeof(A) / sizeof(A[0]);
    
    Double(A, size);
    cout << "The Array Elements after doubling them are : " << endl; 
    for(int ii=0; ii<size; ii++){
        cout << A[ii] << " "; 
    }
    
    
     
    return 0;
}