/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

// Difference Between Sum and Product. 
void diff_bw_sum_and_prod(int n){
    int sum = 0; 
    int prod = 1; 
    
    while(n!=0){
        
        int last_digit = n%10;
        prod = prod * last_digit; 
        sum = sum + last_digit; 
        n = n/10; 
    }
    cout << "The Difference between the sum and products is : " << prod - sum << endl;  
}



// Hamming Weight Problem : Return the number of '1 Bits' in the number. 
void count_1_bit(uint32_t a){   // Input : Unsigned integer : Can only represent non-negative values which is 32 bit.  
    
    int count = 0; 
    while(a!=0){
        if(a&1 == 1){     // if the last digit & 1 = 1, then last digit has to be 1. AND Gate working. 
            count++; 
        }
        a = a>>1;         // Right Shifting the number for subsequent digits.
    }

    cout << "The number of 1 Bits in the number are " << count << endl; 
}


int main()
{
    int n = 4421; 
    uint32_t a = 00000000000000000000000000001011; 
    
    cout << n%10 << endl;   // gives the last digit
    cout << n/10 << endl;   // removes the last digit from the number.
    
    // Difference Between Sum and Product. 
    diff_bw_sum_and_prod(n);
    // Determining the number of 1 Bits in the integer. 
    count_1_bit(a); 
    
    
    
    


    return 0;
}