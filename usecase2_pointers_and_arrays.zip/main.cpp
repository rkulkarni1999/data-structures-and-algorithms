/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


int main()
{
    
    int A[] = {2,4,5,8,1};
    cout << A << endl;       // Only the address of the first element will be printed.  
    cout << A+1 << endl;     // Address of the 2nd Element. 
    cout << *A << endl;      // First Element will be printed. 
    cout << *(A+1) << endl;  // Second element will be printed. 
    cout << A[1] << endl;    // Second Element will be printed. 
    cout << &A[1] << endl;   // Address of the second element will be printed. 
    
    int* p = nullptr;
    p = A; 
    
    cout << p << endl;
    cout << *(p+1) << endl; // Gives the 2nd Element. 
    
    
    
    
    return 0;
}