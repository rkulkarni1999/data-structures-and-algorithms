/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int factorial(int n){
    for(int ii=n-1; ii>1; ii--){
        n = (n *ii); 
    }
    return n; 
}

int nCr(int n, int r){ 
    
    int fac_n = factorial(n); 
    cout << "Factorial n : "<< fac_n << endl; 
    int fac_r = factorial(r); 
    cout << "Factorial r : "<< fac_r << endl;
    int fac_n_minus_r = factorial(n-r); 
    cout << "Factorial n - r : "<< fac_n_minus_r << endl;
    int res; 
    res = fac_n / (fac_r * fac_n_minus_r); 
    
    return res; 
     
}


int main()
{
    // int a = 3;                             // Can only use int and chars here, not floats, double, etc. 
    
    // cout << endl; 
    
    // switch (a*10){
        
    //     case 5 : cout << "hello there" << endl; 
    //         break;
        
    //     case 10 : cout << "I am" << endl; 
    //         break;
        
    //     case 15 : cout << "using" << endl; 
    //         break;
            
    //     case 20 : cout << "whatsapp" << endl; 
    //         break;
        
    //     default : cout << "I am not using whatsapp" << endl; 
        
    // }
    
    int n,r; 
    cout << "Please enter n and r" << endl; 
    cin >> n >> r; 
    int result1 = nCr(n,r);
    
    cout << "The Final Result is : " << result1 << endl; 
    return 0;
}