/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int* add(int* a, int* b){     // Function that returns a Pointer. 
    int* c = new int;
    *c = (*a) + (*b);
    return c; 
}

int main()
{
    int a =10, b =20; 
    int* ptr = add(&a,&b); 
    cout << *ptr << endl; 
    delete ptr; 

    return 0;
}
