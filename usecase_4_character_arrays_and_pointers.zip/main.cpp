/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

// Character Arrays = Strings. 
// Rule : size(character array) >= number of characters in the string + 1 - null stored in the last. 
// Rule Definition : A string in C++ has to be terminated using a null character

using namespace std;

// Defining a custom print function. Input : Pointer to an array Output : prints the string. 
void print(char* D){
    int ii = 0; 
    while(D[ii] != '\0'){
        // cout << D[ii];
        cout << *(D + ii); 
        ii++; 
    }
    cout << "\nLoop Terminated!!"<< endl; 
}

int main()
{
    // char C[4] = {'J', 'O', 'H', 'N'};
    char C[15]; 
    C[0] = 'J';
    C[1] = 'O';
    C[2] = 'H';
    C[3] = 'N';    // Not Null Terminated
    
    // cout << C[4] << endl; 
    
    char D[10]; 
    D[0] = 'J';
    D[1] = 'O';
    D[2] = 'H';
    D[3] = 'N';
    D[4] = '\0';   // Null Terminated  
    
    
    // cout << D << endl; 
    
    print(D); 

    return 0;
}