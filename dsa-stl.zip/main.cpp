/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// Front  - gives element. 
// Back   - gives element. 
// Begin  - gives iterator.
// end    - gives iterator.
// clear  - remove all elements. 
// erase  - remove certain elements, range can be specified. Takes Iterators and not indices. 
// insert - used for sets; 
// next   - Operation for iterators. goes to the next iteration.
// prev   - Operation for iterators. goes to the previous iteration.

#include <iostream>
#include <vector>      // STL container 1
#include <deque>       // STL container 2
#include <string>      // STL container 3
#include <list>        // STL container 4 - Doubly Linked List. 
#include <stack>       // STL container 5 - LIFO
#include <queue>       // STL container 6 - FIFO     
#include <set>         // STL container 7 - Ordered or Unordered. 
#include <map>         // STL container 8 - Value Key Pairs. 

using namespace std;

void print_vector(vector<int>& a){
    for(auto element : a){
        cout << element << " "; 
    }
    cout << endl; 
}

void print_deque(deque<int>& a){
    for(auto element : a){
        cout << element << " "; 
    }
    cout << endl; 
}

void print_list(list<int>& a){
    for(auto element : a){
        cout << element << " "; 
    }
    cout << endl; 
}

// Printing Stack not possible this way. 
// void print_stack(stack<int>& a){
//     for(auto element : a){
//         cout << element << " "; 
//     }
//     cout << endl; 
// }

void print_set(set<int>& a){
    for(auto element : a){
        cout << element << " "; 
    }
    cout << endl; 
}

void check_flag(string a, bool b){
    if(b==true){
        cout << a << "True" << endl;  
    }else{
        cout << a << "False" << endl; 
    }
}

int main()
{
    
    /* VECTORS */
    
    cout << "-------------------------" << endl;   
    cout << "VECTORS" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    vector<int> v; 
    
    v.push_back(1); 
    v.push_back(2); 
    v.push_back(3); 
    cout << "Capacity : " << v.capacity() << endl;
    v.push_back(4);
    v.push_back(5);
    cout << "Capacity : " << v.capacity() << endl;  // Total Memory allocated to the vector. 
    cout << "Size : " << v.size() << endl;          // Actual Size.
    cout << "Indexing : " << v.at(2) << endl;
    cout << "First Element : " << v.front() << endl;
    cout << "Last Element : " << v.back() << endl;
    
    cout << "Popping the Last Element" << endl; 
    v.pop_back();
    print_vector(v);
    
    cout << "Clearing All elements" << endl; 
    v.clear();
    print_vector(v);
    
    cout << "Making a vector with same elements " << endl; 
    vector<int> f(5,2); 
    print_vector(f); 
    
    cout << "Making a copy of the Vector " << endl; 
    vector<int> g(f); 
    print_vector(g); 
    
    /* DEQUE */ 
    // Key Features : Popping, Insertion, Deletion with ease for Front and Back Elements. 
    //                Memory Allocation not contigious, unlike arrays and vectors. 
    cout << "-------------------------" << endl;   
    cout << "DEQUES" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    deque<int> d; 
    
    cout << "Adding elements to the back of the deque" << endl; 
    for(size_t ii=0; ii<5; ii++){
        d.push_back(ii); 
    }
    cout << "Adding Elements to the front of the deque" << endl; 
    d.push_front(5); 
    
    print_deque(d);
    
    cout << "Getting rid of Front and Back Elements" << endl; 
    d.pop_back(); 
    d.pop_front(); 
    
    print_deque(d); 
    
    cout << "Checking if the Deque is empty" << endl; 
    
    bool flag = d.empty(); 
    check_flag("Deque is empty : ", flag);
    
    cout << "Clearing Certain Elements from the Deque. Note : Have to provide Range in iterators" << endl; 
    d.erase(d.begin(), d.end()-1);
    print_deque(d); 
    
    cout << "Clearing all elements from the Deque" << endl; 
    d.clear();
    print_deque(d); 
    
    /* DOUBLY LINKED LIST */
    // Key Features : has 2 pointers, 1 at the front and one at the back. 
    //                Direct Indexing not possible. Have to travese the list.  
    cout << "-------------------------" << endl;   
    cout << "LISTS" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    list<int> l; 
    
    cout << "Adding Elements to the Front and Back of the list" << endl; 
    for(size_t ii=1; ii<6; ii++){
        l.push_back(ii*10);
        l.push_front(ii);
    }
    print_list(l);
    
    cout << "Erasing elements from the list, not that a range cannot be provided unlike vectors or deques" << endl; 
    l.erase(l.begin());      // End Does not work.    
    print_list(l); 
    
    /* STACKS */
    // Key Features : Can only play with the last element. LAST IN FIRST OUT (LIFO) 
    //                Iteration through the stack is not possible. Can do top() and pop()   
    
    cout << "-------------------------" << endl;   
    cout << "STACKS" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    stack<string> s; 
    
    cout << "Adding element to the Stack. cannot be added to the front" << endl; 
    
    s.push("Rutwik");
    s.push("Sudhakar");
    s.push("Kulkarni");
    
    cout << "Accessing the top element in the stack" << endl; 
    
    cout << s.top() << endl; 
    
    s.pop(); 
    
    cout << s.top() << endl; 
    
    /* QUEUE */
    // Key Features : Can only play with the First element. FIRST IN FIRST OUT (FIFO) 
    //                Iteration through the queue is not possible. Can do top() and pop()  
    cout << "-------------------------" << endl;   
    cout << "QUEUES" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    queue<string> k; 
    
    cout << "Adding element to the Queue" << endl; 
    
    k.push("Rutwik");
    k.push("Sudhakar");
    k.push("Kulkarni");
    
    cout << "Accessing the front element in the stack. Note : Back is also possible but cannot be popped" << endl; 
    
    cout << k.front() << endl; 

    k.pop(); 
    
    cout << k.front() << endl;
    
    /* PRIORITY QUEUE */
    // Key Features : MAX HEAP : the element fetched from the priority queue will always be the greatest in value.  
    //                 
    cout << "-------------------------" << endl;   
    cout << "PRIORITY QUEUES" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    cout << "Defining a Max Heap : " << endl; 
    priority_queue<int> max_hp; 
    
    cout << "Defining a Min Heap : " << endl; 
    priority_queue<int, vector<int>, greater<int>> min_hp;   
    
    max_hp.push(1);
    max_hp.push(3);
    max_hp.push(2);
    max_hp.push(0);
    
    cout << "Printing all elements in Max Heap : " << endl; 
    
    int size_hp = max_hp.size(); 
    
    for(size_t ii=0; ii<size_hp; ii++){
        cout << max_hp.top() << " "; 
        max_hp.pop(); 
    }
    cout << endl; 
    
    min_hp.push(1);
    min_hp.push(3);
    min_hp.push(2);
    min_hp.push(0);
    
    cout << "Printing all elements in Min Heap : " << endl; 
     
    int size_hp_min = min_hp.size(); 
    
    for(size_t ii=0; ii<size_hp_min; ii++){
        cout << min_hp.top() << " "; 
        min_hp.pop(); 
    }
    cout << endl; 
    
    /* ORDERED SETS */
    // Key Features : Stores Unique Elements Only. Similar to vectors for operations.   
    //                Returns Elements in Sorted Order. not sorted for unordered     
    //                Can only push and remove elements. Cannot change the elements.
    //                Ordered are slower than unordered. 
    cout << "-------------------------" << endl;   
    cout << "SETS" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
    
    set<int> t; 
    
    cout << "Adding Elements to the Set {5,5,5,1,6,6,0,3}" << endl; 
    t.insert(5);
    t.insert(5);
    t.insert(5);
    t.insert(1);
    t.insert(6);
    t.insert(6);
    t.insert(0);
    t.insert(3);
    
    print_set(t);  
    
    cout << "Defining a iterator" << endl; 
    
    set<int>::iterator start = t.begin(); 
    
    cout << "Erasing Elements from the Set" << endl; 
    
    t.erase(next(start));
    t.erase(t.begin());
    
    print_set(t); 
    
    cout << "Counting how many times an element exists in the set, Because this is a Set, this acts like a Boolean to check if exists or not" << endl; 
    cout << t.count(8) << endl; 
    
    cout << "Finding the Index of the Element we are supposed to find. Note that find() uses Iterators and not index " << endl; 
    
    set<int>::iterator kk = t.find(6);

    cout << "Value Present at iterator is " << *kk << endl;  
    
    /* MAPS */
    // Key Features : Contain Key Value Pairs. Similar to Dictionaries in Python.   
    //                Can be ordered or unordered depending on the definition.      
    //                Keys have to be unique. 
    //                 
    cout << "-------------------------" << endl;   
    cout << "MAPS" << endl; 
    cout << "-------------------------" << endl; 
    cout << endl; 
 
    map<int, string> m; 
    
    cout << "Adding Elements to maps" << endl; 
    
    m[1] = "Rutwik"; 
    m[12] = "Sudhakar"; 
    m[2] = "Kulkarni"; 
    
    cout << "Inserting Elements in the Map" << endl; 
    
    m.insert({5, "Surekha"}); 
    
    for(auto ii:m){
        cout << ii.first <<" : "<< ii.second << endl;
    }
    
    cout << "Checking if a Key Exists in the map" << endl; 
    
    cout << "Does 5 Exist ? Ans : " << m.count(5) << endl; 
    
    cout << "Erasing pairs from Maps" << endl; 
    
    m.erase(m.begin(), next( m.begin() ) ); 
    
    
    for(auto ii:m){
        cout << ii.first <<" : "<< ii.second << endl;
    }
    
    cout << "Using find() which returns the iterator" << endl; 
    
    auto ff = m.find(5); 
    
    for(auto ii=ff; ii!=m.end(); ii++){
        cout << (*ii).first << endl; 
    }
    
    
}

