/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>

using namespace std;

// Problem 1 : Reverse An Integer.  
int reverse_integer(int n){
    
    int INT_MIN = -pow(2, 31); 
    int INT_MAX = pow(2, 31) - 1; 
    
    int ii = 0; 
    int res = 0; 
    int q = n; 
    
    while(n!=0){
        int last_digit = n%10;                       // extracting the last digit. 
        if(res < INT_MIN/10 || res > INT_MAX/10){    // Condition to check if the solution exceeds bounds. 
            return 0;  
        }
        res = (10*res) + last_digit;                 // formula for placing the digits sequentially. 
        ii++; 
        n = n/10;                                    // popping the last digit from integer. 
    }
    
    return res;  
}

// Problem 2 : Complement of Base 10 Integers. 
int bitwise_complement(int n){
    
    int res = 0; 
    int ii = 0; 
    while(n!=0){
        int last_bit = (~n)&1;                  // Extracting the last bit from the Integer. 
        res = res + (pow(10, ii)*last_bit);     // formula for placing the individual numbers sequentially. 
        n = n>>1;                               // Right shifting the numbers to reach the terminating condition.  
        ii++; 
    }
    
    int res2 = 0; 
    
    // Converting the number back to Decimal from Binary
    int kk = 0; 
    while(res!=0){
        int last_digit = res%10; 
        
        if(last_digit == 1){
            res2 = res2 + (pow(2,kk)); 
        }
        kk++;
        res = res/10;
    }
    return res2; 
}

// Problem 2 : Another, more efficient Method. 
// Bitwise complement - another method, creating a mask. 
int bitwise_complement_mask(int n){
    // Edge Case. 
    if(n==0){
        return 1; 
    }
    
    int q = n; 
    int bitmask = 0; 
    // Create a bitmask with all relevant bits set to 1. 
    while(n!=0){
        
        bitmask = (bitmask<<1) | 1;    // Converting the last bit to 1, for counts equal to the iterations until the terminal condition is reached. 
        n = n>>1;                      // Right shifting until the terminating condition is reached.  
    }
    cout << "Bitmask : " << endl; 

    return q ^ bitmask;                // XOR gate and not OR gate, because 1 | 1 is also 1 and we want 0 i.e XOR. 
}

// Problem 3 : Power of 2.
// Trick : Max value of a 32 bit integer pow(2,31) and -pow(2,31) 
bool isPower_of_two(int n){
    
    if(n==0){
        return 0; 
    }
    
    int res = 1; 
    int MAX = 31; 
    
    for(int ii=0; ii<=MAX; ii++){
        if(n == res  || n == -res ){
            return 1; 
        }
        res = res*2;
    }
    return 0; 
}


int main()
{
    
    // // Problem 1 : Reverse Integer. 
    // int n;
    // cout << "Give Integer to be reversed" << endl; 
    // cin >> n; 
    // int result1 = reverse_integer(n);
    // cout << result1 << endl; 
    
    // Problem 2 : Given an Integer, convert to binary and then return its complement number. 
    // int l;
    // cout << "Give binary to be complemented" << endl; 
    // cin >> l; 
    // // int result2 = bitwise_complement(l);
    // int result2 = bitwise_complement_mask(l);
    // cout << result2 << endl; 
    
    // Problem 3 : 
    int k;
    cout << "Give Number to be checked for the power of 2" << endl; 
    cin >> k; 
    bool result3 = isPower_of_two(k);
    cout << result3 << endl; 
    // Problem 4 : 
    
    // Problem 5 :
    
    // Problem 6 : 
    
    // Problem 7 :

    return 0;
}