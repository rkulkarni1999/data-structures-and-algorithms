/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std; 

// Pointers : Can point to any data type. 

int add(int a, int b){
    return a+b; 
}

int main()
{
    int c;
    
    int (*p)(int, int);  // Defining a pointer to function.  
    p = &add;            // Assigning the address to function. 

    c = (*p)(2,3);       // dereferencing and executing the function.  
     
    cout << c << endl; 
    
    return 0;
}
