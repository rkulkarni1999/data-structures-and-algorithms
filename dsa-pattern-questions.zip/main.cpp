/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

// Pattern 1 :   ***
            //   ***
            //   ***
void pattern_1(){
    int n; 
    cout << "Enter the Number of rows and colums that you want" << endl; 
    cin >> n; 
    
    int ii = 0; 
    
    while (ii<n){
        int jj = 0;
        while (jj < n){
            cout << '*';
            jj++; 
        }
        cout << endl; 
        ii++;
    }
}

// Pattern 2 :   111
            //   222 
            //   333
void pattern_2(){
    int n; 
    cout << "Please Enter the number of rows and columns" << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii<n){
        int jj = 0; 
        while(jj < n){
            cout << ii+1 << " "; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}            

// Pattern 3 :   1234
            //   1234
            //   1234
            //   1234
void pattern_3(){
    int n; 
    cout << "Please Enter the number of rows and colums you want" << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            cout << jj+1 << " "; 
            jj++; 
        }
        cout << endl; 
        ii++;
    }
}

// Pattern 4 :   123
            //   456
            //   789
void pattern_4(){
    int n; 
    cout << "Enter the number of rows and columns you want " << endl; 
    cin >> n; 
    
    int count = 0; 
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            cout << count + 1<< " ";
            jj++; 
            count++; 
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 5 :   *
            //   **
            //   ***
void pattern_5(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            cout << "*"; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}

// pattern_6 :   1 
            //   22
            //   333 
void pattern_6(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            cout << ii+1; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 7 :   1
            //   23
            //   456
void pattern_7(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int count = 0; 
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            cout << count+1 << " "; 
            count++; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}
// Pattern 8 :   1
            //   21
            //   321
void pattern_8(){
    int n; 
    cout << "Please Enter the Number of rows you want " << endl;
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            cout << (ii-jj)+1 << " "; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}
// Pattern 9 :   AAA 
            //   BBB
            //   CCC
void pattern_9(){
    int n; 
    cout << "Enter then number of rows you want" << endl; 
    cin >> n; 
    // char letters[] = {'A', 'B', 'C', 'D'}; 
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            char ch = 'A' + ii; 
            cout << ch << " "; 
            jj++; 
        }
        cout << endl; 
        ii++; 
    }
}
// Pattern 10 :    ABC 
                // ABC 
                // ABC
void pattern_10(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            char c; 
            c = 'A' + jj; 
            cout << c << " "; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 11 :    ABC 
                // DEF 
                // GHI
void pattern_11(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int count = 0; 
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            char c; 
            c = 'A' + count; 
            cout << c << " "; 
            count++; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 12 :    ABC 
                // BCD 
                // CDE
void pattern_12(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            char c = 'A' + (ii + jj); 
            cout << c << " "; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 13 :    A 
                // BB 
                // CCC
void pattern_13(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            char c = 'A' + ii; 
            cout << c << " "; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 14 :    A 
                // BC 
                // DEF
void pattern_14(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0;
    int count = 0; 
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            char c = 'A' + count; 
            cout << c << " "; 
            count++; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 15 :    A 
                // BC 
                // CDE
                // DEFG
void pattern_15(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0;
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            char c = 'A' + ii + jj; 
            cout << c << " "; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 16 :    D 
                // CD 
                // BCD
void pattern_16(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0;
    while(ii < n){
        int jj = 0; 
        while(jj <= ii){
            char c = ('A' + (n-ii) + jj) -1; 
            cout << c << " "; 
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 17 :    ---* 
                // --**
                // -***
                // ****
void pattern_17(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0;
    while(ii < n){
        int jj = 0; 
        while(jj < n){
            
            if(jj < (n -ii) ){
                cout << '-';
            }else{
                cout << '*'; 
            }
            jj++;
        }
        cout << endl; 
        ii++; 
    }
}

// Pattern 18 :       1    
                //   121
                //  12321
                // 1234321
void pattern_18(){
    int n; 
    cout << "Please Enter the number of rows you want " << endl; 
    cin >> n; 
    
    int ii = 0; 
    while(ii < n){
        
        int jj = (n-ii);      
        while(jj){                // Iterates till space is 0. 
            cout << " "; 
            jj--;                 // decrementing space to terminate the loop. 
        }
        
        int kk = 0; 
        while(kk <= ii){
            cout << kk+1; 
            kk++; 
        }
        
        int ff = 0; 
        while(ff <= ii -1){
            cout << ii - ff ; 
            ff++; 
        }
        
        cout << endl; 
        ii++;
    }
    
}

int main(){
    // pattern_1(); 
    // pattern_2(); 
    // pattern_3();
    // pattern_4(); 
    // pattern_5(); 
    // pattern_6(); 
    // pattern_8(); 
    // pattern_9(); 
    // pattern_10();
    // pattern_11();
    // pattern_12();
    // pattern_13();
    // pattern_14(); 
    // pattern_15(); 
    // pattern_16();
    // pattern_17();
    pattern_18(); 
    return 0;
}


