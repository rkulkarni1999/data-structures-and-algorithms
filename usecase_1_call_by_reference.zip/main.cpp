/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

// Use Case 1 of Pointers : Pointers as Function Arguments - Call by reference. 

void increment(int a){                  // Only changes the local variable, does not change the variable in main.  
    a = a+1;
}

void increment_using_ptr(int* p){       // Changes the variable in main, because it uses address.
    (*p) = (*p) + 1; 
}

int main()
{
    int a = 10; 
    
    increment(a);       
    cout << a << endl;     

    increment_using_ptr(&a); 
    cout << a << endl; 
    

    return 0;
}