/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>


using namespace std;

int binary_search(int* arr, int size, int key){
    
    int start = 0;    
    int end = size-1; 
    int mid = (start + (end-start)/2);    // Incase start and end indices are both high. 
    
    while(start<=end){
        
        if(arr[mid] == key){
            return mid; 
            
        }
        
        if(arr[mid] < key){
            start = mid +1; 
        }
        
        if(arr[mid] > key){
            end =  mid -1; 
        }
         
        mid = (start+ (end-start)/2);  // I case start index blows up to be a high index value, sum(start, end) can be out of range for int. There this is done. 
    }
    return -1; 
    
}

int main()
{    
    int even[] = {2,4,6,8,12,18}; 
    int odd[] = {3,8,11,14,16}; 
    int key = 8; 
    int size_even = sizeof(even)/sizeof(even[0]);
    int size_odd = sizeof(odd)/sizeof(odd[0]);
    
    int res1 = binary_search(even, size_even, key);
    int res2 = binary_search(odd, size_odd, key);

    cout << "Result 1 : " << res1 << endl << "Result 2 : " << res2; 

    return 0;
}